let a=50;
a=10;

console.log(a);

